<?php 

$fname= $_POST['fname'];
$lname= $_POST['lname'];
$email= $_POST['email'];
$number= $_POST['number'];
$msg= $_POST['msg'];

$conn = new mysqli('localhost','root','','travel_db');
if($conn->connect_error){
    die('Connection failed :' .$connect_error);
}else{
    $stmt= $conn->prepare("insert into contact_table(fname, lname, email, number, msg) values(?, ?, ?, ?, ?)");
    $stmt->bind_param("sssis", $fname, $lname, $email, $number, $msg);
    $stmt->execute();
    $conn->close();
}
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Contact us</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
        }

        p {
            color: #777;
        }

        .thank-you-message {
            background-color: lightskyblue;
            color: #fff;
            padding: 10px;
            border-radius: 5px;
        }

        a {
            text-decoration: none;
            color: #4CAF50;
            font-weight: bold;
        }
        .msg{
            color:black;
        }
        .no{
            color:red;
        }
        input{
            margin: 5px;
            padding: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Call us..?</h1>
        <p>Your Query Received, We'll reach to you shortly.. We look forward to serving you!</p>
        <div class="thank-you-message">
            <p class="msg">Thank You....</p>
        </div>

         
        <a href="login_form.php"><input type="submit" value="Home"></a>
    </div>
</body>
</html>
