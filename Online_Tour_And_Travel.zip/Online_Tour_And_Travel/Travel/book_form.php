

<?php
    $pkg_name = $_POST['pkg_name'];
    $pkg_price = $_POST['pkg_price'];
    $name= $_POST['name'];
    $email= $_POST['email'];
    $phone= $_POST['phone'];
    $address= $_POST['address'];
    $location= $_POST['location'];
    $guests= $_POST['guests'];
    $arrivals= $_POST['arrivals'];
    $leaving= $_POST['leaving'];

    $conn = new mysqli('localhost','root','','travel_db');
    if($conn->connect_error){
        die('Connection failed :' .$connt->connect_error);
    }else{
        $stmt= $conn->prepare("insert into book_table(pkgname,pkgprice,name, email, phone, address, location, guests, arrivals, leaving) values(?,?,?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sisssssiss",$pkg_name,$pkg_price,$name, $email, $phone, $address, $location, $guests, $arrivals, $leaving);
        $stmt->execute();
        echo "payment under processing please don't switch or close the tab";
        $conn->close();

    }



?>