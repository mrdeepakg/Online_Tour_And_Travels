<?php
error_reporting(error_reporting() & ~E_WARNING);


$fname = $_POST['pfname'];
$number = $_POST['plname'];
$email = $_POST['pemail'];
$pkgname = $_POST['pkgname'];
$pkgprice = $_POST['pkgprice'];
$guests = $_POST['guests'];
$pkg_dur = $_POST['pkg_dur'];
$pkg_dis = $_POST['pkg_dis'];
$pkg_mode = $_POST['pkg_mode'];

$total = $guests*$pkgprice;



$conn = new mysqli('localhost', 'root', '', 'travel_db');
if ($conn->connect_error) {
    die('Connection failed :' . $connt->connect_error);
} else {
    $stmt = $conn->prepare("insert into pay_record(fname,lname,email,pkgname,pkgtotal,guests) values(?,?,?,?,?,?)");
    $stmt->bind_param("ssssii", $fname, $number, $email,$pkgname,$total,$guests);
    $stmt->execute();
    
    
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        .dialog-box {
            width: 800px;
            height: 500px;
            margin: 0 auto;
            padding-left: 20px;
            padding-right: 20px;
            border: 1px solid black;
        }
        /* .button-container {
            display: flex;
            align-items: center;
        } */
        .gt1{
            display: inline;
            padding-left: 230px;
            
        }
        h3{
            text-align: center;
        }
        

.btn1{
    display: inline-block;
    background: rgb(238, 128, 26);
    margin-top: 0.5rem;
    color:rgb(255, 255, 255);
    align-items: center;
    font-size: 1.2rem;
    padding:0.5rem 2rem;
    cursor: pointer;
    position: relative;
    left: 1200px;
    top:20px;
    
}
.btn1:hover{
    background: rgb(238, 142, 86);
}

.head{
    text-align: center;
    
}
p{
    font-weight: bold;
    font-size: 1.2rem;
}
span{
    color:red;
}
.header{
    position: static;
    top:0; left:0; right:0;
    z-index: 1000;
    background-color: orange;
    display: flex;
    padding-top: 0.5rem;
    padding-bottom: 1rem;
    box-shadow: black;
    padding-left: 380px;
    justify-content: space-between;
}
.btn{
    display: flex;
    align-items:center;
    justify-content: space-between;
    flex-wrap: wrap;
}
nav{
    display: flex;
    align-items:center;
    justify-content: space-between;
    flex-wrap: wrap;
}
.head{
    position: static;
    top:0; left:0; right:0;
    z-index: 1000;
    background-color: orange;
    display: flex;
    padding-top: 0rem;
    padding-bottom: -1rem;
    box-shadow: black;
    padding-left: 95px;
    justify-content: space-between;
}
.nav{
    text-align: center;
}
.btn2{
    position: relative;
    left: 1200px;
    top: -80px;
    
}
    </style>
</head>

<body>
<?php
function generateRandomTransactionCode($length = 10) {
    $characters = '0123456789';
    $code = '';
    $maxIndex = strlen($characters) - 1;

    for ($i = 0; $i < $length; $i++) {
        $randIndex = mt_rand(0, $maxIndex);
        $code .= $characters[$randIndex];
    }

    return $code;
}

// Usage
$transactionCode = generateRandomTransactionCode(4); // Change the length as needed



        echo "
        <nav class='header'><h2>Gtravel Reciept Page</h2></nav><br>
    <div id='dialog-box' class='dialog-box'>
        <nav class='head'><h3 class='head' >GTravel &nbsp; Receipt No: <span>GT".$transactionCode."</span></p></h3><hr></nav>
        <hr/>
     <div class='order-message-container'>
    <div class='message-container'>
       <div>
        <nav>
           <p> Package Name: <span>" . $pkgname . "</span></p><br>
           <p> Name : <span>" . $fname . "</span> </p>&nbsp;&nbsp;
          <p> Number : <span>" . $number . "</span> </p><br>
          <p> Email : <span>" . $email . "</span> </p>&nbsp;&nbsp;
          <p>No. of guests:<span>".$guests."</span> </p><br>
          <p>Package price:<span>" .$pkgprice. "</span> </p>

          <p>Payable Amt. :<span>".$guests. " x " .$pkgprice. "</span></p><br>

          <p> Total Amount Paid: <span>" . $total . "</span> </p><br>

          <p>Convenience fee: 0/- </p><br>
          <br><p class='total'>Total :<span>".$total."</span></p>
          <br><pclass='total'>Duration :<span>".$pkg_dur."</span></p>
          <br><pclass='total'>Destinations :<span>".$pkg_dis."</span></p>
          <br><pclass='total'>Inclusion :<span>Hotel/ Meal/ ".$pkg_mode."</span></p>
          
        </nav>
       
    </div>    
</div><br>
<div class='gt1' >
    <img src='images/travel.jpg' alt=''>
   </div><br>
</div>";

        error_reporting(error_reporting() | E_WARNING);

        ?>
        </p>
    </div>
<br>
<div class='btn'>
<button class='btn1' id='printButton'><i class='fa-solid fa-print'></i> Print</button> 
</div>

       
    <script>
        // JavaScript for printing the receipt
        const printButton = document.getElementById('printButton');
        printButton.addEventListener('click', () => {
            window.print();
        });
    </script>

<form action="thankyou.php" method="post">
<span><input type="hidden" id="email" name="receiptno" value="GT<?php echo $transactionCode?>"  class="name"></span>   
<span><input type="hidden" id="email" name="pkgname" value="<?php echo $pkgname?>"  class="name"></span>   
<span><input type="hidden" id="email" name="fname" value="<?php echo $fname?>"  class="name"></span>   
<span><input type="hidden" id="email" name="email" value="<?php echo $email?>"  class="name"></span>   
<span><input type="hidden" id="email" name="total" value="<?php echo $total?>"  class="name"></span>  
<span><input type="hidden" id="email" name="status" value="booked"  class="name"></span>  
 
<a href='home.php'><input type="submit" class='btn1 btn2' value="Home"></a>


</form>


</body>

</html>