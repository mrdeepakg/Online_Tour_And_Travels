<?php include 'packagehead.php'; ?>

<section class="mypkg">
        <h1 class="myht">Religious Place Packages</h1>
        <?php

        $select_inter = mysqli_query($conn, "SELECT * FROM `products` WHERE package_type='religious'");
        if (mysqli_num_rows($select_inter) > 0) {
            while ($inter = mysqli_fetch_assoc($select_inter)) {
        ?>
                
                <div class="my-pkg-cont">

                    <div class="pkg-box">
                        <div class="image">
                            <img src="../Travel/images/<?php echo $inter['image']; ?>" alt="">
                        </div>
                        <div>
                            <h2 class="content pkg-title"><?php echo $inter['name']; ?></h2>
                            <ul>
                                <li><?php echo $inter['duration']; ?></li>
                                <li><?php echo $inter['discription']; ?></li>
                                <li><i class="fa-solid fa-hotel"></i> Hotel,&nbsp;<i class="fa-solid fa-utensils "></i> Meal,&nbsp;<i class="fa-solid fa-car"></i> Cab</li>
                                <li>Free Cancellation</li>
                            </ul>

                            <p class="content pkg-title">&#8360;.<b><?php echo $inter['price']; ?>/-</b></p>
                            <div class="content"><a href="book.php?book=<?php echo $inter['id'] ?>" class="content pkg-btn">Book Now</a></div>
                        </div>
                    </div>
                    <br>

                </div>
        <?php
            };
        };
        ?>
    </section>



<?php include 'pkgfoot.php'; ?>