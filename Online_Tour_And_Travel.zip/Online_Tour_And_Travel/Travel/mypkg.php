<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
:root{
    --main-color:#8e44ad;
    --black:#222;
    --white:#fff;
    --light-black:#777;
    --light-white:#fff9;
    --dark-bg:rgba(0,0,0,.7);
    --light-bg:#eee;
    --border:.1rem solid var(--black);
    --box-shadow: 0 .5rem 1rem rgba(0,0,0,.1);
    --box-shadow: 0 1.5rem 3rem rgba(0,0,0,.3);
}
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

:root{
    --main-color:#8e44ad;
    --black:#222;
    --white:#fff;
    --light-black:#777;
    --light-white:#fff9;
    --dark-bg:rgba(0,0,0,.7);
    --light-bg:#eee;
    --border:.1rem solid var(--black);
    --box-shadow: 0 .5rem 1rem rgba(0,0,0,.1);
    --box-shadow: 0 1.5rem 3rem rgba(0,0,0,.3);
}

*{
    font-family: 'Poppins', sans-serif;
    margin:0; padding:0;
    box-sizing: border-box;
    outline: none; border: none;
    text-decoration: none;
    text-transform: capitalize;
}


html{
    font-size: 62.5%;
    overflow-x: hidden;
}



section{
    padding: 5rem 10%;
}





.btn{
    display: inline-block;
    background: var(--black);
    margin-top: 1rem;
    color:var(--white);
    font-size: 1.7rem;
    padding:1rem 3rem;
    cursor: pointer;
}
.btn:hover{
    background: var(--main-color);
}
.myht{
    text-align: center;
    margin-bottom: 3rem;
    font-size: 6rem;
    text-transform: uppercase;
    color: var(--black);
}




.mypkg .my-pkg-cont{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(30rem, 1fr));
    gap: 2rem;
}



.mypkg .my-pkg-cont .pkg-box{
    border:var(--border);
    box-shadow: var(--box-shadow);
    background: var(--white);
    
}


.mypkg .my-pkg-cont .pkg-box:hover .image img{
    transform: scale(1.1);
}

.mypkg .my-pkg-cont .pkg-box .image{
    height: 25rem;
    overflow: hidden;
}

.mypkg .my-pkg-cont .pkg-box .image img{
    height: 100%;
    width: 100%;
    object-fit: cover;
    transition: .2s linear;
}
.mypkg .my-pkg-cont .pkg-box .content{
    padding: 2rem;
    text-align: center;
}



.mypkg .my-pkg-cont .pkg-box .content{
    padding: 2rem;
}
.mypkg .my-pkg-cont .pkg-box .content h3{
    font-size: 2.5rem;
    color: var(--black);   
}
.mypkg .my-pkg-cont .pkg-box .content p{
    font-size: 1.5rem;
    color: var(--light-black);
    line-height: 2;
    padding: 1rem 0;   
}

.mypkg .load-more{
    text-align: center;
    margin-top: 2rem;
}

</style>
    <!-- <link rel="stylesheet" href="pkg.css"> -->
</head>
<body>
<section class="mypkg">
    <h1 class="myht">top destination</h1>
    <div class="my-pkg-cont">

    <div class="pkg-box">
            <div class="image">
                <img src="images/img3.jpg" alt="">
            </div>
            <div class="content">
                <h3>adventure & tour</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                <a href="login_form.php" class="btn">Book Now</a>
            </div>
        </div>
        <div class="pkg-box">
            <div class="image">
                <img src="images/img3.jpg" alt="">
            </div>
            <div class="content">
                <h3>adventure & tour</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                <a href="login_form.php" class="btn">Book Now</a>
            </div>
        </div>
        <div class="pkg-box">
            <div class="image">
                <img src="images/img3.jpg" alt="">
            </div>
            <div class="content">
                <h3>adventure & tour</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                <a href="login_form.php" class="btn">Book Now</a>
            </div>
        </div>
        <div class="pkg-box">
            <div class="image">
                <img src="images/img3.jpg" alt="">
            </div>
            <div class="content">
                <h3>adventure & tour</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                <a href="login_form.php" class="btn">Book Now</a>
            </div>
        </div>
    
      
        
    </div>
    <div class="load-more"><span class="btn"><a href="login_form.php">load more</a></span></div>
</section>

</body>
</html>