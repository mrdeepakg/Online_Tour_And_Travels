<?php

@include 'config.php';

session_start();

if (!isset($_SESSION['user_name'])) {
    header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>about</title>

<!-- swiper link -->
<link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">

   <!-- font -->
    <link rel="stylsheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" >
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<!-- custom css -->
<link rel="stylesheet" href="mystyle.css" >

<style>
#out{
    display: inline;
    position: relative;
    left: -70px;
    font-size: 2.5rem;
}

.logindetail{
    display: inline;
    text-decoration: underline;
    border-radius: 7px;
    font-size: 1.5rem;
    position: relative;
    left: -230px;
}
body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 10px;
        }

        header{
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
            font-size: 20px;
        }

        h1 {
            margin: 0;
        }

        .con_container {
            height: 700px;
            max-width: 1200px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            font-size: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        p {
            line-height: 1.8;
        }
</style>

</head>
<body>
    

<!-- header start -->
<section class="header">
<a href="login_form.php" id="out"><abbr title="Logout">⏪</abbr></a>
        <a class="logindetail logo">&nbsp;Hi,<?php echo $_SESSION['user_name'] ?>&nbsp;&nbsp;</a>
        <a href="#" class="logo"><span style="color:red;" class="gt">G</span>travel</a>
    <nav class="navbar">
        <a href="home.php">home</a>
        <a href="about.php">about</a>
        <a href="Package.php">package</a>
        <a href="MyTrips.php">MyTrips</a>
        
    </nav>
    
 <div id="menu-btn" class="fas fa-bars">☰</div>

</section>

<!-- header ends -->


<div class="heading" style="background:url(images/homeslide1.jpg) no-repeat">
    <h1>about us</h1>
</div>

<!-- about section starts -->


<header>
        <p>Gtravel - Exploring the World Together</p>
    </header>

    <div class="con_container">
        <h2>Who We Are....</h2>
        <p>
            We are a passionate team of travel enthusiasts dedicated to providing you with the best travel experiences. Our mission is to help you discover the beauty of the world through carefully crafted tours and adventures.
        </p><br>

        <h2>Our Vision</h2>
        <p>
            Our vision is to make travel accessible, enjoyable, and memorable for everyone. We believe that every journey is an opportunity to create lasting memories and foster a deep connection with the world's diverse cultures and landscapes.
        </p><br>

        <h2>Why Choose Us</h2>
        <p>
            <ul>
                <li>Experienced and knowledgeable tour guides</li>
                <li>Customized travel itineraries</li>
                <li>Wide range of destinations and adventures</li>
                <li>Exceptional customer support</li>
            </ul>
        </p><br>

        <h2>Contact Us</h2>
        <p>
            If you have any questions or would like to book a tour, feel free to <a href="contact.php">contact us</a>.
        </p><br>
    </div>

<!-- about section ends -->






<footer>
    <section class="footer">

        <div class="box-container">

            <div class="box">
                <h3>Quick links</h3>
                <a href="home.php"><i class="fas fa-angle-right"></i> home</a>
                <a href="about.php"><i class="fas fa-angle-right"></i>about</a>
                <a href="Package.php"><i class="fas fa-angle-right"></i>package</a>
                <a href="book.php"><i class="fas fa-angle-right"></i>book</a>          
            </div>

            <div class="box">
                <h3>Extra links</h3>
                <a href="#"><i class="fas fa-angle-right"></i>Ask questions</a>
                <a href="#"><i class="fas fa-angle-right"></i>About Us</a>
                <a href="#"><i class="fas fa-angle-right"></i>Privacy Policy</a>
                <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>            
            </div>

            <div class="box">
                <h3>Contact info</h3>
                <a href="#"><i class="fas fa-phone"></i>+91 123-4567-890</a>
                <a href="#"><i class="fas fa-phone"></i>+91 111-4567-890</a>
                <a href="#"><i class="fas fa-envelope"></i>mymail@gmail.com</a>
                <a href="#"><i class="fas fa-map"></i>Mumbai, India - 400104</a>         
            </div>

            <div class="box">
                <h3>follow us</h3>
                <a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
                <a href="#"><i class="fab fa-twitter"></i>twitter</a>
                <a href="#"><i class="fab fa-insta"></i>instagram</a>
                <a href="#"><i class="fab fa-linkedin"></i>linkedin</a>
            </div>

        </div>

    </section>
</footer>







<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<script src="script.js"></script>

</body>
</html>




