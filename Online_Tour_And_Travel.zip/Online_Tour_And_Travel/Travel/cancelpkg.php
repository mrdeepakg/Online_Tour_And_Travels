<?php 
$receiptno = $_GET['id'];

$conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Faild");
$sql = "UPDATE receipt_table SET status='requested' WHERE receiptno='$receiptno'";
    $result = mysqli_query($conn,$sql) or die("Query Unsuccessful");

mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Cancel Request</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
        }

        p {
            color: #777;
        }

        .thank-you-message {
            background-color: lightskyblue;
            color: #fff;
            padding: 10px;
            border-radius: 5px;
        }

        a {
            text-decoration: none;
            color: #4CAF50;
            font-weight: bold;
        }
        .msg{
            color:black;
        }
        .no{
            color:red;
        }
        input{
            margin: 5px;
            padding: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Request Received...</h1>
        <p>Your request for cancellation is received. We look forward to serving you!</p><br>
        <p>Check Request Status...</p>
        <div class="thank-you-message">
            <p class="msg">For Receipt No: <span class="no"><?php echo $receiptno ?></span></p>
        </div>
        <a href="MyTrips.php"><input type="submit" value="Home"></a>
    </div>
</body>
</html>
