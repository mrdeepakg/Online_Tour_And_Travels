<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
:root{
    --main-color:#8e44ad;
    --black:#222;
    --white:#fff;
    --light-black:#777;
    --light-white:#fff9;
    --dark-bg:rgba(0,0,0,.7);
    --light-bg:#eee;
    --border:.1rem solid var(--black);
    --box-shadow: 0 .5rem 1rem rgba(0,0,0,.1);
    --box-shadow: 0 1.5rem 3rem rgba(0,0,0,.3);
}

</style>
    <link rel="stylesheet" href="pkg.css">
</head>
<body>
<section class="packages">
    <h1 class="heading-title">top destination</h1>
    <div class="box-container">

    <div class="box">
            <div class="image">
                <img src="images/img3.jpg" alt="">
            </div>
            <div class="content">
                <h3>adventure & tour</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                <a href="login_form.php" class="btn">Book Now</a>
            </div>
        </div>
    <div class="box">
            <div class="image">
                <img src="images/img3.jpg" alt="">
            </div>
            <div class="content">
                <h3>adventure & tour</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                <a href="login_form.php" class="btn">Book Now</a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/img3.jpg" alt="">
            </div>
            <div class="content">
                <h3>adventure & tour</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                <a href="login_form.php" class="btn">Book Now</a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/img1.jpeg" alt="">
            </div>
            <div class="content">
                <h3>adventure & tour</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                <a href="login_form.php" class="btn">Book Now</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images/img2.jpg" alt="">
            </div>
            <div class="content">
                <h3>adventure & tour</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                <a href="login_form.php" class="btn">Book Now</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images/img3.jpg" alt="">
            </div>
            <div class="content">
                <h3>adventure & tour</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                <a href="login_form.php" class="btn">Book Now</a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/img3.jpg" alt="">
            </div>
            <div class="content">
                <h3>adventure & tour</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                <a href="login_form.php" class="btn">Book Now</a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/img3.jpg" alt="">
            </div>
            <div class="content">
                <h3>adventure & tour</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                <a href="login_form.php" class="btn">Book Now</a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="images/img3.jpg" alt="">
            </div>
            <div class="content">
                <h3>adventure & tour</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                <a href="login_form.php" class="btn">Book Now</a>
            </div>
        </div>
      
        
    </div>
    <div class="load-more"><span class="btn"><a href="login_form.php">load more</a></span></div>
</section>

</body>
</html>