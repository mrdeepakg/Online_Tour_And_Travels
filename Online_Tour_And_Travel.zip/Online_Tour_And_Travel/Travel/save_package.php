<?php

@include 'config.php';

session_start();

if (!isset($_SESSION['user_name'])) {
    header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>package</title>

    <!-- swiper link -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">

    <!-- font -->
    <link rel="stylsheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- custom css -->
    <link rel="stylesheet" href="mystyle.css">
    <script src="script.js"></script>
</head>

<body>
    <style>
        .logindetail {
            display: inline;
            text-decoration: underline;
            border-radius: 7px;
            font-size: 1.5rem;
            position: relative;
            left: -230px;
        }

        #out {
            display: inline;
            position: relative;
            left: -70px;
            font-size: 2.5rem;
        }
    </style>

    <!-- header start -->
    <section class="header">
        <a href="login_form.php" id="out"><abbr title="Logout">⏪</abbr></a>
        <a class="logindetail logo">&nbsp;Hi,<?php echo $_SESSION['user_name'] ?>&nbsp;&nbsp;</a>
        <a href="#" class="logo">GTravel</a>
        <nav class="navbar">
            <a href="home.php">home</a>
            <a href="about.php">about</a>
            <a href="Package.php">package</a>
            <a href="book.php">book</a>

        </nav>

        <div id="menu-btn" class="fas fa-bars">☰</div>

    </section>

    <!-- header ends -->


    <div class="heading" style="background:url(images/homeslide1.jpg) no-repeat">
        <h1>package</h1>
    </div>


    <!-- package section starts -->
    <section class="packages">
        <h1 class="heading-title">top destination</h1>
        <div class="box-container">

            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Maldives Canareef Resort Package With Flights</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="images/pkg2.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Exclusive Bali Honeymoon Tour Packages For A Memorable Vacay</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Budget-Friendly Dubai Packages From Atlantis For A Thrilling Vacay</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>

            <div class="box">
                <div class="image">
                    <img src="images/img3.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Idyllic Maldives Honeymoon Tour Package</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Budget-Friendly Dubai Packages From Atlantis For A Thrilling Vacay</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>adventure & tour</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Most Reasonable Goa Honeymoon Tour Packages</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Fantastic Andaman Honeymoon Package</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Coorg Package For 2 Nights And 3 Days</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Best 4N 5D Andaman Sightseeing Tour Package For A Refreshing Getaway</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Hills & Houseboat: Munnar and Alleppey Honeymoon Package</h3>                    
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Splendid Dubai Abu Dhabi Tour Packages For An Amazing Holiday</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Memorable Mauritius Tour Package</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Mesmerising Manali Trip Package From Chandigarh</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Mesmerising Manali Trip Package From Chandigarh</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Mesmerising Manali Trip Package From Chandigarh</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Mesmerising Manali Trip Package From Chandigarh</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>
            <div class="box">
                <div class="image">
                    <img src="images/img1.jpeg" alt="">
                </div>
                <div class="content">
                    <h3>Mesmerising Manali Trip Package From Chandigarh</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias, tempore!</p>
                    <a href="book.php" class="btn">Book Now</a>
                </div>
            </div>

    </div>
       <div class="load-more"><span class="btn">load more</span></div>
  </section>

    <!-- package section ends -->



    <footer>
        <section class="footer">

            <div class="box-container">

                <div class="box">
                    <h3>Quick links</h3>
                    <a href="home.php"><i class="fas fa-angle-right"></i> home</a>
                    <a href="about.php"><i class="fas fa-angle-right"></i>about</a>
                    <a href="Package.php"><i class="fas fa-angle-right"></i>package</a>
                    <a href="book.php"><i class="fas fa-angle-right"></i>book</a>
                </div>

                <div class="box">
                    <h3>Extra links</h3>
                    <a href="#"><i class="fas fa-angle-right"></i>Ask questions</a>
                    <a href="#"><i class="fas fa-angle-right"></i>About Us</a>
                    <a href="#"><i class="fas fa-angle-right"></i>Privacy Policy</a>
                    <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>
                </div>

                <div class="box">
                    <h3>Contact info</h3>
                    <a href="#"><i class="fas fa-phone"></i>📞+91 123-4567-890</a>
                    <a href="#"><i class="fas fa-phone"></i>📞+91 111-4567-890</a>
                    <a href="#"><i class="fas fa-envelope"></i>mymail@gmail.com</a>
                    <a href="#"><i class="fas fa-map"></i>Mumbai, India - 400104</a>
                </div>

                <div class="box">
                    <h3>follow us</h3>
                    <a href="#"><i class="fab fa-facebook-f">facebook</i></a>
                    <a href="#"><i class="fab fa-twitter">twitter</i></a>
                    <a href="#"><i class="fab fa-insta">instagram</i></a>
                    <a href="#"><i class="fab fa-linkedin">linkedin</i></a>
                </div>

            </div>

        </section>
    </footer>







    <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

    <script src="script.js"></script>

</body>

</html>