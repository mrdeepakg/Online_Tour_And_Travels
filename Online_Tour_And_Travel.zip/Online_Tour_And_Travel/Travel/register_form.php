<?php

@include 'config.php';

if(isset($_POST['submit'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = md5($_POST['password']);
   $cpass = md5($_POST['cpassword']);
   $user_type = $_POST['user_type'];

   $select = " SELECT * FROM user_data WHERE email = '$email' && password = '$pass' ";

   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){

      $error[] = 'user already exist!';

   }else{

      if($pass != $cpass){
         $error[] = 'password not matched!';
      }else{
         $insert = "INSERT INTO user_data(name, email, password, user_type) VALUES('$name','$email','$pass','$user_type')";
         mysqli_query($conn, $insert);
         header('location:login_form.php');
      }
   }

};


?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="mystyle.css">

</head>


<style>
   body{
   background: url("images/myimg1.jpeg");
}
.autoWritter {
    font-family: arial;
    display: table;
    /* margin: 50px auto; */
}
.autoWrite-text {
    color: #ffffff;
    display: inline-block;
    overflow: hidden;
    white-space: nowrap;
    letter-spacing: 2px;
    /*-- Call text and cursor animation --*/
    animation: write 3s steps(40, end), cursor .7s step-end infinite;
    font-size: 70px;
    border-right: 4px solid;
}

/*-- Write text as Animated --*/
@keyframes write {
	from {
		width: 0%
	}
	to {
		width: 100%
	}
}

/*-- Animated blink cursor CSS--*/
@keyframes cursor{
	from, to {
		border-color: transparent;
	}
	50% {
		border-color: #ff9800;
	}
}
.autoWritter{
   width: 2px;
}

.rpage{
   display: inline-block;
   position: relative;
   font-size: 55px;
   left: 200px;
   top: 100px;
}
span{
   color: red;
}

</style>
<body>
   
<!-- header -->
   
<section class="header">
<a href="#" class="logo"><span style="color:red;" class="gt">G</span>travel</a>
        <nav class="navbar">
            <a href="#">home</a>
            <a href="contact.php" >Contact Us</a>
            <a href="#">about</a>
            <a href="#" onclick="alert('Login First');">packages</a>
            
            <a href="login_form.php">Login</a>
        </nav>
        <div id="menu-btn" class="fas fa-bars">☰</div>
    </section>
<!-- header -->
<h2 class="rpage">Welcome to GTravel <br><span>Regester To Book</span></h2>


<div class="form-container">

   <form action="" method="post">
      <h3>register now</h3>
      <?php
      if(isset($error)){
         foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
         };
      };
      ?>
      <input type="text" name="name" required placeholder="enter your name">
      <input type="email" name="email" required placeholder="enter your email">
      <abbr title="Password should be min 8 characters containing at least one digit,one lower,upper,special character">
      <input type="password" name="password" min="8" required placeholder="enter your password" ></abbr>
      <input type="password" name="cpassword" min="8" required placeholder="confirm your password" >
      <select name="user_type">
         <option value="user">user</option>
      </select>
      <input type="submit" name="submit" value="register now" class="form-btn">
      <p>already have an account? <a href="login_form.php">login now</a></p>
   </form>

</div>

<!-- footer -->

<footer >
    <section class="footer">

        <div class="box-container">

            <div class="box">
                <h3>Quick links</h3>
                <a href="home.php"><i class="fas fa-angle-right"></i> home</a>
                <a href="abouts.php"><i class="fas fa-angle-right"></i>about</a>
                <a href="login_form.php"><i class="fas fa-angle-right"></i>package</a>
                <a href="login_form.php"><i class="fas fa-angle-right"></i>book</a>          
            </div>

            <div class="box">
                <h3>Extra links</h3>
                <a href="#"><i class="fas fa-angle-right"></i>Ask questions</a>
                <a href="#"><i class="fas fa-angle-right"></i>About Us</a>
                <a href="#"><i class="fas fa-angle-right"></i>Privacy Policy</a>
                <a href="#"><i class="fas fa-angle-right"></i>terms of use</a>            
            </div>

            <div class="box">
                <h3>Contact info</h3>
                <a href="#"><i class="fas fa-phone"></i>📞+91 123-4567-890</a>
                <a href="#"><i class="fas fa-phone"></i>📞+91 111-4567-890</a>
                <a href="#"><i class="fas fa-envelope"></i>mymail@gmail.com</a>
                <a href="#"><i class="fas fa-map"></i>Mumbai, India - 400104</a>         
            </div>

            <div class="box">
                <h3>follow us</h3>
                <a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
                <a href="#"><i class="fab fa-twitter"></i>twitter</a>
                <a href="#"><i class="fab fa-insta"></i>instagram</a>
                <a href="#"><i class="fab fa-linkedin"></i>linkedin</a>
            </div>

        </div>

        <div class="credit">created by <span>Gupta Developers</span> | all right reserved!</div>

    </section>
</footer>

<!-- footer -->


</body>
</html>