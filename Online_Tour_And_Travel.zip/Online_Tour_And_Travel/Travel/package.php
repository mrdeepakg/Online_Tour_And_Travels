<?php include 'packagehead.php'; ?>


<!-- package section starts -->

<section class="mypkg">
        <h1 class="myht">All Available Packages</h1>
        
        <?php

        $select_products = mysqli_query($conn, "SELECT * FROM products");
        if (mysqli_num_rows($select_products) > 0) {
            while ($fetch_product = mysqli_fetch_assoc($select_products)) {
        ?>
                
                <div class="my-pkg-cont">

                    <div class="pkg-box">
                        <div class="image">
                            <img src="../Travel/images/<?php echo $fetch_product['image']; ?>" alt="">
                        </div>
                        <div>
                            <h2 class="content pkg-title"><?php echo $fetch_product['name']; ?></h2>
                            <ul>
                                <li><?php echo $fetch_product['duration']; ?></li>
                                <li><?php echo $fetch_product['discription']; ?></li>
                                <li>Hotel/&nbsp;Meal/&nbsp;<?php echo $fetch_product['mode']; ?></li>
                                <li>Free Cancellation</li>
                            </ul>

                            <p class="content pkg-title">&#8360;.<b><?php echo $fetch_product['price']; ?>/-</b></p>
                            <div class="content"><a href="book.php?book=<?php echo $fetch_product['id'] ?>" class="content pkg-btn">Book Now</a></div>
                        </div>
                    </div>
                    <br>

                </div>
        <?php
            };
        };
        ?>
    </section>

<?php include 'pkgfoot.php'; ?>