<?php
$s_no= $_POST['sno'];
$b_name = $_POST['name'];
$b_email = $_POST['email'];
$b_phone = $_POST['phone'];
$b_address = $_POST['address'];
$b_location = $_POST['location'];
$b_guests = $_POST['guests'];
$b_arrivals = $_POST['arrivals'];
$b_leaving = $_POST['leaving'];

$conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Failed");

$sql = "UPDATE book_table SET name='{$b_name}',email='{$b_email}',phone='{$b_phone}',address='{$b_address}',location='{$b_location}',guests='{$b_guests}',arrivals='{$b_arrivals}',leaving='{$b_leaving}' WHERE sno=($s_no)";
$result = mysqli_query($conn, $sql) or die("Query Successful.");
header("Location: http://localhost/myphp/Online_Tour_And_Travel/crud_html/index.php");

mysqli_close($conn);


?>