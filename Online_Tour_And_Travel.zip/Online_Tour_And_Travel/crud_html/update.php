<?php include 'admin_page.php'; ?>
<div id="main-content">
<br/><br/>
    <h2>Edit Record</h2>
    <form class="post-form" action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
        <div class="form-group">
            <label>S No.</label>
            <input type="number" name="sno" />
        </div>
        <input class="submit" type="submit" name="showbtn" value="Show" />
    </form>

    <?php
    if(isset($_POST['showbtn'])){

    $conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Faild");
    $sno_id=$_POST['sno'];
    $sql = "SELECT * FROM book_table WHERE sno = {$sno_id}";
    $result = mysqli_query($conn,$sql) or die("Query Unsuccessful");
    
    if(mysqli_num_rows($result)>0){

        while($row=mysqli_fetch_assoc($result)){
    
    ?>

    <form class="post-form" action="updatedata.php" method="post">
        <div class="form-group">
            <label for="">Name</label>
            <input type="hidden" name="sno"  value="<?php echo $row['sno'];?>" />
            <input type="text" name="name" value="<?php echo $row['name'];?>" />
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" value="<?php echo $row['email'];?>" />
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="number" name="phone" value="<?php echo $row['phone'];?>" />
        </div>
        <div class="form-group">
            <label>Address</label>
            <input type="text" name="address" value="<?php echo $row['address'];?>" />
        </div>
        <div class="form-group">
            <label>Location</label>
            <input type="text" name="location" value="<?php echo $row['location'];?>" />
        </div>
        <div class="form-group">
            <label>Guests</label>
            <input type="number" name="guests" value="<?php echo $row['guests'];?>" />
        </div>
        <div class="form-group">
            <label>Arrivals</label>
            <input type="date" name="arrivals" value="<?php echo $row['arrivals'];?>" />
        </div>
        <div class="form-group">
            <label>Leaving</label>
            <input type="date" name="leaving" value="<?php echo $row['leaving'];?>" />
        </div>
    <input class="submit" type="submit" value="Update"  />
    </form>
<?php
        }
    }
}
?>
</div>
</div>
</body>
</html>
