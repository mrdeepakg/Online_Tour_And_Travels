<?php include 'admin_page.php'; 


    $as_no = $_GET['aid'];
    $conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Faild");
    $sql1 = "UPDATE user_data SET user_type ='admin' WHERE sno='$as_no'";
    $result1 = mysqli_query($conn,$sql1) or die("Query Unsuccessful");
    header("Location: http://localhost/myphp/Online_Tour_And_Travel/crud_html/manageUser.php");
    echo 'done';



    $us_no = $_GET['uid'];
    $conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Faild");
    $sql2 = "UPDATE user_data SET user_type ='user' WHERE sno='$us_no'";
    $result2 = mysqli_query($conn,$sql2) or die("Query Unsuccessful");
    header("Location: http://localhost/myphp/Online_Tour_And_Travel/crud_html/manageUser.php");
    echo 'done';


    $ds_no = $_GET['did'];
    $conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Faild");
    $sql3 = "DELETE FROM user_data WHERE sno='$ds_no'";
    $result3 = mysqli_query($conn,$sql3) or die("Query Unsuccessful");
    header("Location: http://localhost/myphp/Online_Tour_And_Travel/crud_html/manageUser.php");
    echo 'done';

    mysqli_close($conn);
    


?>