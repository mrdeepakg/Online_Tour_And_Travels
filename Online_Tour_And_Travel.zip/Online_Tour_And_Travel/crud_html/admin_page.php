<?php

$conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Faild");


session_start();

if(!isset($_SESSION['admin_name'])){
   header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/admincss.css">
</head>
<style>
.admin-name{
  display: inline-block;
  position: relative;
  left: 1100px;
  
  font-size: 25px;
  font-weight: bold;
}





</style>

<body>
<!-- <div class="header"></div> -->
<div class="header">
  <div class="admin-name"><p>Hi Admin, <?php echo $_SESSION['admin_name'] ?></p>    
</div>
</div>
  <input type="checkbox" class="openSidebarMenu" id="openSidebarMenu">
  <label for="openSidebarMenu" class="sidebarIconToggle">
    <div class="spinner diagonal part-1"></div>
    <div class="spinner horizontal"></div>
    <div class="spinner diagonal part-2"></div>
  </label>
  <div id="sidebarMenu">
    <ul class="sidebarMenuInner">
      <li>Admin <span><?php echo $_SESSION['admin_name'] ?></span></li>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li>
        <details>
          <summary>Bookings</summary>
          <!-- <a href="index.php"><option value="">View</option></a> -->
          <ul>
            <li><a href="index.php"><option value="">View</option></a></li>
            <li><a href="update.php"><option value="">Update</option></a></li>
            <li><a href="delete.php"><option value="">Delete</option></a></li>
          </ul>

        </details>
      </li>
      <li><a href="contact_data.php">Contact Queries</a></li>
      <li><a href="manageUser.php">Manage Users</a></li>
      <li><a href="add.php">Manage Packages</a></li>
      <li><a href="status.php">Booking Status</a></li>
      <li><a href="../crud_html/../Travel/login_form.php" id="out">Logout</a></li>
    </ul>
  </div>
