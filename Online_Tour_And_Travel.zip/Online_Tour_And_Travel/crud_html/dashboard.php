<?php include 'admin_page.php'; ?>

<?php

$conn = mysqli_connect("localhost", "root", "", "travel_db") or die("Connection Faild");
$query1 = "SELECT COUNT(*) AS count FROM book_table";
$result1 = mysqli_query($conn, $query1) or die("Query Unsuccessful");

while ($row = mysqli_fetch_assoc($result1)) {

  $output = $row['count'];
}


$query2 = "SELECT COUNT(*) AS count FROM contact_table";
$result2 = mysqli_query($conn, $query2) or die("Query Unsuccessful");

while ($row = mysqli_fetch_assoc($result2)) {

  $contact = $row['count'];
}

$query3 = "SELECT COUNT(*) AS count FROM products";
$result3 = mysqli_query($conn, $query3) or die("Query Unsuccessful");

while ($row = mysqli_fetch_assoc($result3)) {

  $packages = $row['count'];
}

$query4 = "SELECT COUNT(*) AS count FROM user_data";
$result4 = mysqli_query($conn, $query4) or die("Query Unsuccessful");

while ($row = mysqli_fetch_assoc($result4)) {

  $users = $row['count'];
}

$query5 = "SELECT COUNT(*) AS count FROM receipt_table WHERE status='requested'";
$result5 = mysqli_query($conn, $query5) or die("Query Unsuccessful");

while ($row = mysqli_fetch_assoc($result5)) {

  $cancel = $row['count'];
}

mysqli_close($conn);

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylsheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <style>
    @import url("https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap");

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Poppins", sans-serif;
    }

    :root {
      --background-color1: #fafaff;
      --background-color2: #ffffff;
      --background-color3: #ededed;
      --background-color4: #cad7fda4;
      --primary-color: #4b49ac;
      --secondary-color: #0c007d;
      --Border-color: #3f0097;
      --one-use-color: #3f0097;
      --two-use-color: #5500cb;
    }

    body {
      background-color: var(--background-color4);
      max-width: 100%;
      overflow-x: hidden;
    }

    .box-container {
      display: block;
   position: relative;
   top:100px;
   left:300px;
    }

    .box {
      display: inline-block;
    height: 200px;
    width: 350px;
    padding: 20px;
    margin: 20px;
    padding-bottom: 10px;
    border: 1px solid black;
    border-radius: 40px;
    background-color: var(--one-use-color);
      cursor: pointer;
      transition: transform 0.3s ease-in-out;
    }

    .box:hover {
      transform: scale(1.08);
    }

 

    .box img {
      height: 80px;
      position: relative;
      left: 200px;
      top: -100px;
    }

    .box .text {
      color: white;
    }

    .topic {
      font-size: 25px;
      font-weight: 400;
      letter-spacing: 1px;
      position: relative;
      top: 30px;
      left: 30px;
    }

    .topic-heading {
      font-size: 50px;
      letter-spacing: 3px;
      position: relative;
      top: 10px;
      left: 50px;
    }

    .box4{
      position: relative;
      left: 150px;
     
    }
    .box5{
      position: relative;

      left: 150px;
    }
  </style>
</head>


<div class="box-container">

  <div class="box box1">
  <a href="index.php">
    <div class="text">
      <h2 class="topic-heading"><?php echo $output; ?></h2>
      <h2 class="topic">Bookings</h2>
      <span><img src="right.jpeg" alt="Views"></span>
    </div>
    </a>

    
  </div>

    
  <div class="box box2">
  <a href="add.php">
    <div class="text">
      <h2 class="topic-heading"><?php echo $packages; ?></h2>
      <h2 class="topic">Manage Packages</h2>
      <img src="https://cdn4.iconfinder.com/data/icons/world-travel-guide/512/travel-01-512.png" alt="comments">

    </div>
  </a>
  </div>


  <div class="box box3">
    <a href="contact_data.php">
    <div class="text">
      <h2 class="topic-heading"><?php echo $contact; ?></h2>
      <h2 class="topic">Contact Requests</h2>
      <img src="https://media.geeksforgeeks.org/wp-content/uploads/20221210184645/Untitled-design-(32).png" alt="comments">

    </div>
    </a>
    <!-- <img src=""
          alt="likes"> -->
  </div>



  <div class="box box4">
    <a href="manageUser.php">
    <div class="text">
      <h2 class="topic-heading"><?php echo $users; ?></h2>
      <h2 class="topic">Users</h2>
      <img src="https://th.bing.com/th/id/R.8e2c571ff125b3531705198a15d3103c?rik=gzhbzBpXBa%2bxMA&riu=http%3a%2f%2fpluspng.com%2fimg-png%2fuser-png-icon-big-image-png-2240.png&ehk=VeWsrun%2fvDy5QDv2Z6Xm8XnIMXyeaz2fhR3AgxlvxAc%3d&risl=&pid=ImgRaw&r=0" alt="comments">

    </div>
    </a>  
  </div>

  <div class="box box5">
    <a href="status.php">
    <div class="text">
      <h2 class="topic-heading"><?php echo $cancel; ?></h2>
      <h2 class="topic">Cancel Request</h2>
      <img src="https://th.bing.com/th/id/OIP.ztKZSOrnUVSoJ-s5OSotMwHaHa?pid=ImgDet&rs=1" alt="comments">

    </div>
    </a>  
  </div>
  
</div>
</body>

</html>