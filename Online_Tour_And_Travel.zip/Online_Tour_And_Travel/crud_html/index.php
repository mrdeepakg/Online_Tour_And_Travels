
<?php include 'admin_page.php'; ?>
<div id="main-content">
    <br/><br/>
    <h2>All Booking Records</h2>
    <?php
    $conn = mysqli_connect("localhost","root","","travel_db") or die("Connection Faild");
    $sql = "SELECT * FROM book_table";
    $result = mysqli_query($conn,$sql) or die("Query Unsuccessful");
    
    if(mysqli_num_rows($result)>0){

    ?>
    <table cellpadding="7px">
        <thead>
        <th>S No.</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Address</th>
        <th>Location</th>
        <th>Guests</th>
        <th>Check-in Date</th>
        <th>Leaving</th>
        
        <th>Action</th>
        </thead>
        <tbody>
            <?php 
            while($row = mysqli_fetch_assoc($result)){
            ?>
            <tr>
                <td><?php echo $row['sno'] ?></td>
                <td><?php echo $row['name'] ?></td>
                <td><?php echo $row['email'] ?></td>
                <td><?php echo $row['phone'] ?></td>
                <td><?php echo $row['address'] ?></td>
                <td><?php echo $row['location'] ?></td>
                <td><?php echo $row['guests'] ?></td>
                <td><?php echo $row['arrivals'] ?></td>
                <td><?php echo $row['leaving'] ?></td>
                <td>
                    <a href='edit.php?id=<?php echo $row['sno'] ?>'>Edit</a>
                    <a href='delete-inline.php?id=<?php echo $row['sno'] ?>'>Delete</a>
                </td>
            </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
    <?php }
    ?>
</div>
</div>
</body>
</html>
